Validated Personal Information - First name, Last Name and Email Address - check if its present or not
Validated Email Address , First Name and Last Name with regex as well
Validated the radio button for Car selection
Validated The Rental Location Information - Either Address code should be entered or State/City/Street should be entered
