var alphas:string[]; 
alphas = ["Deiva","Raghavi","3","4"] 
console.log(alphas[0]); 
console.log(alphas[1]);