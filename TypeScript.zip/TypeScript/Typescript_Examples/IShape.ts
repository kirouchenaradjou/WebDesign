export interface IShape { 
   draw(); 
}