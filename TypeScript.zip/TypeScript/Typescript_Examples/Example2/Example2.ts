class Greetings{
greet():void{
 console.log("Hello World!!!") 
}
}
var obj = new Greetings(); 
obj.greet();